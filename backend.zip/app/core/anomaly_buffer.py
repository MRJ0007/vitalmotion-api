from collections import deque
from threading import Lock

MAX_POINTS = 30
_buffers = {}
_lock = Lock()

def push(device_id: str, record: dict):
    with _lock:
        if device_id not in _buffers:
            _buffers[device_id] = deque(maxlen=MAX_POINTS)
        _buffers[device_id].append(record)

def get_last(device_id: str):
    with _lock:
        return list(_buffers.get(device_id, []))

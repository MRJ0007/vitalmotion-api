from pydantic import BaseModel, EmailStr, Field


# -------------------------------------------------
# SIGNUP (SEND OTP)
# -------------------------------------------------

class SignupRequest(BaseModel):
    email: EmailStr
    phone: str
    role: str = Field(..., pattern="^(user|doctor)$")


class SignupResponse(BaseModel):
    message: str


# -------------------------------------------------
# VERIFY OTP
# -------------------------------------------------

class VerifyOtpRequest(BaseModel):
    email: EmailStr
    otp: str


class VerifyOtpResponse(BaseModel):
    message: str


# -------------------------------------------------
# CREATE PASSWORD
# -------------------------------------------------

class CreatePasswordRequest(BaseModel):
    email: EmailStr
    password: str


class CreatePasswordResponse(BaseModel):
    message: str


# -------------------------------------------------
# LOGIN
# -------------------------------------------------

class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class LoginResponse(BaseModel):
    access_token: str
    role: str
    token_type: str = "bearer"


# -------------------------------------------------
# CURRENT USER
# -------------------------------------------------

class UserMeResponse(BaseModel):
    email: EmailStr
    role: str

from fastapi import APIRouter
from app.core.anomaly_buffer import get_last

# optional AI import (failsafe)
try:
    from app.services.anomaly_service import detect_anomaly
except Exception:
    detect_anomaly = None

router = APIRouter(prefix="/anomaly", tags=["Anomaly"])


@router.get("/status/{device_id}")
def anomaly_status(device_id: str):
    vitals = get_last(device_id)

    # Not enough data
    if len(vitals) < 10:
        return {
            "signal": "GRAY",
            "message": "Collecting data"
        }

    # AI unavailable
    if not detect_anomaly:
        return {
            "signal": "UNKNOWN",
            "message": "AI not configured"
        }

    try:
        series = [
            {
                "timestamp": v["timestamp"],
                "value": v["heart_rate"]
            }
            for v in vitals
        ]

        result = detect_anomaly(series)
        severity = result.get("severity", 0)

        if result.get("isAnomaly") and severity > 0.7:
            return {"signal": "RED", "severity": severity}

        if result.get("isAnomaly"):
            return {"signal": "YELLOW", "severity": severity}

        return {"signal": "GREEN"}

    except Exception:
        # AI failure must NEVER crash system
        return {
            "signal": "UNKNOWN",
            "message": "AI error"
        }

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# -------------------------------
# CORE ROUTERS (ALWAYS REQUIRED)
# -------------------------------
from app.routers import (
    health,
    ai,
    sensor,
    alerts,
    ingest,
    auth_doctor,
    admin,
    auth,
    chat,
)

# -------------------------------
# OPTIONAL ANOMALY ROUTER (SAFE)
# -------------------------------
try:
    from app.routers import anomaly
except Exception:
    anomaly = None  # 🔒 FAILSAFE

# -------------------------------
# APP INIT
# -------------------------------
app = FastAPI(title="VitalMotion Backend")

# -------------------------------
# CORS
# -------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------
# ROUTER REGISTRATION
# -------------------------------
app.include_router(auth.router)              # /auth/*
app.include_router(auth_doctor.router)        # /auth-doctor/*
app.include_router(health.router)             # /health
app.include_router(ai.router, prefix="/ai")   # /ai/*
app.include_router(sensor.router)             # /sensor/*
app.include_router(alerts.router)             # /alerts/*
app.include_router(ingest.router)             # /ingest/*
app.include_router(chat.router)               # /chat/*

# -------------------------------
# ADMIN
# -------------------------------
app.include_router(admin.router)              # /admin/*

# -------------------------------
# OPTIONAL ANOMALY (NEVER BLOCKS)
# -------------------------------
if anomaly:
    app.include_router(anomaly.router)        # /anomaly/*


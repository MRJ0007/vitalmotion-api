import os
import requests

ENDPOINT = os.getenv("AZURE_ANOMALY_ENDPOINT")
KEY = os.getenv("AZURE_ANOMALY_KEY")

HEADERS = {
    "Content-Type": "application/json",
    "Ocp-Apim-Subscription-Key": KEY,
}

def detect_anomaly(series):
    url = f"{ENDPOINT}/anomalydetector/v1.1/timeseries/entire/detect"

    payload = {
        "series": series,
        "granularity": "min"
    }

    res = requests.post(url, json=payload, headers=HEADERS, timeout=5)
    res.raise_for_status()
    return res.json()

import time
import os
import google.generativeai as genai

# -------------------------------------------------
# DEMO-SAFE COOLDOWN (seconds)
# -------------------------------------------------
GEMINI_COOLDOWN = 60
_last_gemini_call = 0


# -------------------------------------------------
# GEMINI CONFIG
# -------------------------------------------------
# IMPORTANT: Gemini expects GOOGLE_API_KEY
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))


SYSTEM_PROMPT = """
You are a warm, caring health monitoring assistant.

Rules:
- DO NOT diagnose diseases
- DO NOT prescribe medicines
- DO NOT use markdown, tables, or headings
- DO NOT use bullet symbols

Style:
- Write in short, clear paragraphs
- Use a calm, reassuring tone
- Use gentle emojis inline (❤️ 🫁 🌡️ 🌿)
- Write as plain readable text only

Always include:
- A gentle disclaimer that you are not a medical professional
- Clear explanations of vitals
- Gentle risk awareness
- Simple lifestyle care tips
- A warm, reassuring closing sentence
"""


# -------------------------------------------------
# GENERATE AI INSIGHT (WITH COOLDOWN)
# -------------------------------------------------
def generate_ai_insight(vitals: dict) -> str:
    global _last_gemini_call

    # ------------------------------
    # SAFE NORMALIZATION (NO LOGIC CHANGE)
    # ------------------------------
    heart_rate = vitals.get("heart_rate")
    spo2 = vitals.get("spo2")
    temperature = vitals.get("temperature")

    try:
        if heart_rate is not None:
            heart_rate = int(heart_rate)
        if spo2 is not None:
            spo2 = int(spo2)
        if temperature is not None:
            temperature = float(temperature)
    except Exception:
        # If conversion fails, keep original values
        pass

    now = time.time()

    # ⏳ Cooldown active → skip Gemini safely
    if now - _last_gemini_call < GEMINI_COOLDOWN:
        print("🟡 Gemini cooldown active — skipping AI, using rule-based insight")
        return ""

    try:
        _last_gemini_call = now

        model = genai.GenerativeModel("models/gemini-2.5-flash")

        # ------------------------------
        # EXPLICIT PROMPT (NO MISALIGNMENT)
        # ------------------------------
        prompt = f"""{SYSTEM_PROMPT}

Vitals data:
Heart rate: {heart_rate} beats per minute.
Oxygen saturation: {spo2} percent.
Body temperature: {temperature} degrees Celsius.

Explain these vitals kindly and clearly for a non-medical user.
"""

        response = model.generate_content(prompt)
        return response.text.strip()

    except Exception as e:
        print(f"❌ Gemini AI error: {e}")
        return ""
